export const DB_NAME = "Pariksha";
